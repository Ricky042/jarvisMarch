/*
    Skeleton written by Grady Fitzpatrick for 
    COMP20007 Assignment 1 2024 Semester 1
    
    Header for module which contains convex hull 
        specification data structures and functions.

    Implemented by Grady Fitzpatrick for sample solution.
*/
#include "linkedList.h"
#include "problem.h"
#include "convexHull.h"
#include "stack.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

enum orientationResult {
    COLLINEAR = 0,
    CLOCKWISE = 1,
    COUNTERCLOCKWISE = 2
};

/* Finds the leftmost point in the set of points in the problem. 
    If this point is not unique, returns the index of the point with
    the lower y-coordinate. */
int leftmostPoint(struct problem *p);

int leftmostPoint(struct problem *p){
    int leftmost = 0;
    for(int i = 1; i < p->numPoints; i++){
        if(p->pointsX[i] < p->pointsX[leftmost]){
            leftmost = i;
        } else if(p->pointsX[i] == p->pointsX[leftmost] && p->pointsY[i] < p->pointsY[leftmost]){
            leftmost = i;
        }
    }
    return leftmost;
}

/* Finds the bottommost point in the set of points in the problem. 
    If this point is not unique, returns the index of the point with
    the lower x-coordinate. */
int bottommostPoint(struct problem *p);

int bottommostPoint(struct problem *p){
    int bottommost = 0;
    for(int i = 1; i < p->numPoints; i++){
        if(p->pointsY[i] < p->pointsY[bottommost]){
            bottommost = i;
        } else if(p->pointsY[i] == p->pointsY[bottommost] && p->pointsX[i] < p->pointsX[bottommost]){
            bottommost = i;
        }
    }
    return bottommost;
}

/* Finds the polar angle of the given point */
long double calculatePolarAngle(struct problem *p, int originIdx, int pointIdx);

long double calculatePolarAngle(struct problem *p, int originIdx, int pointIdx){
    assert(originIdx >= 0 && originIdx < p->numPoints);
    assert(pointIdx >= 0 && pointIdx < p->numPoints);
    long double p0x = p->pointsX[originIdx];
    long double p0y = p->pointsY[originIdx];

    long double p1x = p->pointsX[pointIdx];
    long double p1y = p->pointsY[pointIdx];

    long double xDiff = p1x - p0x;
    long double yDiff = p1y - p0y;

    return atan2l(yDiff, xDiff);
}

/* Finds the orientation between the three given points - calculates the angle between 
    the Middle-First vector and Middle-Final vector - if the Middle-First vector is zero-length,
    the gradient of the Middle-Final vector is instead used. */
enum orientationResult orientation(struct problem *p, int idxFirst, int idxMiddle, int idxFinal);

enum orientationResult orientation(struct problem *p, int idxFirst, int idxMiddle, int idxFinal){
    assert(idxFirst >= 0 && idxFirst < p->numPoints);
    assert(idxMiddle >= 0 && idxMiddle < p->numPoints);
    assert(idxFinal >= 0 && idxFinal < p->numPoints);

    /* Use cross-product to calculate turn direction. */
    long double p0x = p->pointsX[idxFirst];
    long double p0y = p->pointsY[idxFirst];

    long double p1x = p->pointsX[idxMiddle];
    long double p1y = p->pointsY[idxMiddle];

    long double p2x = p->pointsX[idxFinal];
    long double p2y = p->pointsY[idxFinal];

    /* Cross product of vectors P1P0 & P1P2 */
    long double crossProduct = (p0x - p1x) * (p2y - p1y) - (p0y - p1y) * (p2x - p1x);

    if(crossProduct == 0){
        if(idxFirst == idxMiddle){
            /* Special case where we are only looking for positive slope of P1P2. */
            if(p2x == p1x){
                /* Special case: dx = 0, vertical */
                if(p2y < p1y){
                    /* Directly upwards */
                    return COUNTERCLOCKWISE;
                } else if(p2y == p1y){
                    /* Same point. */
                    return COLLINEAR;
                } else {
                    return CLOCKWISE;
                }
            }
            long double m = (p2y - p1y) / (p2x - p1x);
            if(m >= 0){
                return COUNTERCLOCKWISE;
            } else {
                return CLOCKWISE;
            }
            
        }
        return COLLINEAR;
    } else if(crossProduct > 0){
        return CLOCKWISE;
    } else {
        return COUNTERCLOCKWISE;
    }
}

struct solution *jarvisMarch(struct problem *p){
    /* Part A - perform Jarvis' March to construct a convex
    hull for the given problem. */
    /* IMPLEMENT HERE */
    /* Implements pseudocode JarvisMarch(points) in Convex Hull slide */
    struct linkedList *hull = NULL;
    struct solution *s = (struct solution *) malloc(sizeof(struct solution));
    assert(s);
    s->operationCount = 0;

    if(p->numPoints < 3){
        /* Insufficient points to form convex hull. */
        s->convexHull = hull;
        return s;
    }

    /* convexHull <- empty list */
    hull = newList();

    /* leftmost <- leftmost_point(points) */
    int leftmostIdx = leftmostPoint(p);

    /* current <- leftmost */
    int current = leftmostIdx;

    /* Initial condition for do-while */
    int firstLoop = 1;

    /* Convenience pointers. */
    long double *px = p->pointsX;
    long double *py = p->pointsY;

    while(current != leftmostIdx || firstLoop){
        firstLoop = 0;
        /* add current to convexHull */
        insertHead(hull, px[current], py[current]);

        /* nextPoint <- points[0] */
        int nextPoint = 0;
        /* for each point in points: */
        for(int idx = 0; idx < p->numPoints; idx++){
            /* (JM Orientation variant) 
                if orientation(current, nextPoint, point) == counterclockwise: */
            /* if orientation(nextPoint, current, point) == counterclockwise: */
            /* if(orientation(p, nextPoint, current, idx) == COUNTERCLOCKWISE){ */
            if(nextPoint == current || orientation(p, nextPoint, current, idx) == COUNTERCLOCKWISE){
                /* nextPoint <- point */
                nextPoint = idx;
            }
        }

        /* current <- nextPoint */
        current = nextPoint;
    }

    s->convexHull = hull;
    return s;
}

/* Merge sorted lists starting at index firstStart - firstEnd and 
    secondStart - secondEnd. Uses the provided copy space to store
    the temporary space. */
void merge(int *idxList, long double *value, int firstStart, int firstEnd, 
    int secondStart, int secondEnd, int length, int *copySpaceIdx, 
    long double *copySpaceValue);

void merge(int *idxList, long double *value, int firstStart, int firstEnd, 
    int secondStart, int secondEnd, int length, int *copySpaceIdx, 
    long double *copySpaceValue){
    /* Second list is empty so already merged. */
    if(secondStart >= length || secondEnd < secondStart){
        return;
    }
    int combinedProgress = 0;
    int progressFirst = 0;
    int progressSecond = 0;
    while((progressFirst + firstStart) <= firstEnd && 
        (progressSecond + secondStart) <= secondEnd){
        if(value[progressFirst + firstStart] <= value[progressSecond + secondStart]){
            copySpaceIdx[combinedProgress] = 
                idxList[progressFirst + firstStart];
            copySpaceValue[combinedProgress] = 
                value[progressFirst + firstStart];
            progressFirst++;
        } else {
            copySpaceIdx[combinedProgress] = 
                idxList[progressSecond + secondStart];
            copySpaceValue[combinedProgress] = 
                value[progressSecond + secondStart];
            progressSecond++;
        }
        combinedProgress++;
    }
    while((progressFirst + firstStart) <= firstEnd){
        copySpaceIdx[combinedProgress] = 
            idxList[progressFirst + firstStart];
        copySpaceValue[combinedProgress] = 
            value[progressFirst + firstStart];
        progressFirst++;
        combinedProgress++;
    }
    while((progressSecond + secondStart) <= secondEnd){
        copySpaceIdx[combinedProgress] = 
            idxList[progressSecond + secondStart];
        copySpaceValue[combinedProgress] = 
            value[progressSecond + secondStart];
        progressSecond++;
        combinedProgress++;
    }
    for(int i = 0; i < combinedProgress; i++){
        idxList[firstStart + i] = copySpaceIdx[i];
        value[firstStart + i] = copySpaceValue[i];
    }
}

/* Mergesorts given idxList by the corresponding values. */
void mergesortPairs(int *idxList, long double *value, int length);

void mergesortPairs(int *idxList, long double *value, int length){
    int *copySpaceIdx = (int *) malloc(sizeof(int) * length);
    assert(copySpaceIdx);
    long double *copySpaceValue = (long double *) malloc(sizeof(long double) * 
        length);
    assert(copySpaceValue);

    for(int windowSize = 1; windowSize < length; windowSize *= 2){
        for(int start = 0; start < length; start += 2 * windowSize){
            /* Find two lists to merge. */
            int firstStart = start;
            int firstEnd = start + windowSize - 1;
            if(firstEnd >= length){
                firstEnd = length - 1;
            }
            int secondStart = firstEnd + 1;
            int secondEnd = secondStart + windowSize - 1;
            if(secondEnd >= length){
                secondEnd = length - 1;
            }
            merge(idxList, value, firstStart, firstEnd, secondStart, secondEnd,
                length, copySpaceIdx, copySpaceValue);
        }
    }
    free(copySpaceIdx);
    free(copySpaceValue);
}

struct solution *grahamScan(struct problem *p){
    /* Part B - perform Graham's Scan to construct a convex
    hull for the given problem. */
    /* IMPLEMENT HERE */
    struct linkedList *hull = NULL;
    struct solution *s = (struct solution *) malloc(sizeof(struct solution));
    assert(s);
    s->operationCount = 0;

    /* ... */
    /* if length(points) < 3: */
    if(p->numPoints < 3){
        /* return empty convex hull */
        /* Insufficient points to form convex hull. */
        s->convexHull = hull;
        return s;
    }

    /* lowest = point with lowest y-coordinate in points */
    int lowestIdx = bottommostPoint(p);
    /* sort points by polar angle with respect to lowest */
    long double *angles = (long double *) malloc(sizeof(long double) * p->numPoints);
    assert(angles);
    int *sortedIdx = (int *) malloc(sizeof(int) * p->numPoints);
    assert(sortedIdx);
    for(int i = 0; i < p->numPoints; i++){
        sortedIdx[i] = i;
    }
    /* Swap first idx with lowestIdx */
    sortedIdx[lowestIdx] = 0;
    sortedIdx[0] = lowestIdx;
    /* Calculate polar angle from lowestIdx. */
    for(int i = 0; i < p->numPoints; i++){
        angles[i] = calculatePolarAngle(p, lowestIdx, sortedIdx[i]);
    }

    mergesortPairs(sortedIdx, angles, p->numPoints);

    /* stack = empty stack */
    struct stack *stack = NULL;

    /* push points[0] to stack */
    push(&stack, &sortedIdx[0]);
    /* push points[1] to stack */
    push(&stack, &sortedIdx[1]);
    /* push points[2] to stack */
    push(&stack, &sortedIdx[2]);

    for(int i = 3; i < p->numPoints; i++){
        /* while orientation(second_top(stack), top(stack), points[i]) != counterclockwise: */
        while(peekTop(stack, 1) && orientation(p, *(int *)peekTop(stack, 1), 
            *(int *)peekTop(stack, 0), sortedIdx[i]) != COUNTERCLOCKWISE){
            /* pop top of stack */
            pop(&stack);
        }
        /* push points[i] to stack */
        push(&stack, &sortedIdx[i]);
    }

    /* return stack */
    /* Stack provides hull in counterclockwise order, so add all to head of list. */
    hull = newList();
    while(stack){
        int idx = *(int *)pop(&stack);
        insertTail(hull, p->pointsX[idx], p->pointsY[idx]);
    }

    s->convexHull = hull;
    return s;
}

void freeSolution(struct solution *s){
    if(! s){
        return;
    }
    if(s->convexHull){
        freeList(s->convexHull);
    }
    free(s);
}

