/*
    Skeleton written by Grady Fitzpatrick for 
    COMP20007 Assignment 1 2024 Semester 1
    
    Implementation details for module which contains doubly-linked list 
        specification data structures and functions.
    
    Implemented by <YOU>
*/

#include "linkedList.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

struct linkedListNode;

struct linkedList {
    struct linkedListNode *head;
    struct linkedListNode *tail;
};

struct linkedListNode {
    /* IMPLEMENT HERE */
    struct linkedListNode *next;
    struct linkedListNode *prev;

    long double x;
    long double y;
};

/* Print out each value in the list from the first value to the final value.
    Each value is printed with the format "(x, y) " where x is the x value
    set when inserting the item and y is the y value set when inserting 
    the item. */
void traverseRingForward(struct linkedList *list){
    /* IMPLEMENT HERE */
    if(! list){
        return;
    }
    struct linkedListNode *tail = list->tail;
    if(tail){
        printf("(%Lf, %Lf) ", tail->x, tail->y);
    }
    struct linkedListNode *item = list->head;
    while(item && item != tail){
        printf("(%Lf, %Lf) ", item->x, item->y);
        item = item->next;
    }
}

/* Print out first the first item of the list, then print out each value in 
    the list from the final value to the second value.
    Each value is printed with the format "(x, y) " where x is the x value
    set when inserting the item and y is the y value set when inserting 
    the item. */
void traverseRingBackwards(struct linkedList *list){
    /* IMPLEMENT HERE */
    if(! list){
        return;
    }
    struct linkedListNode *item = list->tail;
    while(item){
        printf("(%Lf, %Lf) ", item->x, item->y);
        item = item->prev;
    }
}

/* Return a new empty list. */
struct linkedList *newList(){
    /* IMPLEMENT HERE */
    struct linkedList *list = (struct linkedList *) malloc(sizeof(struct linkedList));
    assert(list);

    list->head = NULL;
    list->tail = NULL;

    return list;
}

/* Insert the given x, y pair at the head of the list */
void insertHead(struct linkedList *list, long double x, long double y){
    /* IMPLEMENT HERE */
    struct linkedListNode *item = (struct linkedListNode *) malloc(sizeof(struct linkedListNode));
    assert(item);
    item->x = x;
    item->y = y;
    item->prev = NULL;
    item->next = list->head;
    if(item->next){
        item->next->prev = item;
    }
    list->head = item;
    if(! (list->tail)){
        list->tail = item;
    }
}

/* Insert the given x, y pair at the tail of the list */
void insertTail(struct linkedList *list, long double x, long double y){
    /* IMPLEMENT HERE */
    struct linkedListNode *item = (struct linkedListNode *) malloc(sizeof(struct linkedListNode));
    assert(item);
    item->x = x;
    item->y = y;
    item->prev = list->tail;
    item->next = NULL;
    if(item->prev){
        item->prev->next = item;
    }
    list->tail = item;
    if(! (list->head)){
        list->head = item;
    }
}

/* Free all items in the given list. */
void freeList(struct linkedList *list){
    /* IMPLEMENT HERE */
    if(! list){
        return;
    }
    struct linkedListNode *item = list->head;
    while(item){
        struct linkedListNode *next = item->next;
        free(item);
        item = next;
    }
    free(list);
}
